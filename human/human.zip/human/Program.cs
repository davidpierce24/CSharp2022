﻿Human batman = new Human("Batman", 400, 5000, 200, 200);

Human terry = new Human("Terry");

Console.WriteLine(batman.Attack(terry));